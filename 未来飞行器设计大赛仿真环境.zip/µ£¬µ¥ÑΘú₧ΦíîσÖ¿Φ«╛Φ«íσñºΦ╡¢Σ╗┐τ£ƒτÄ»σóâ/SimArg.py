missile_str = '.\close_middle_py.dll'  # 调用的模型路径，若加载失败，可改为绝对路径

class InitialData(object):
    def __init__(self):
        self.log_tacview = True          # 是否开启内置的仿真文件记录功能
        self.log_csv = False  # 是否输出记录文件
        self.dll_str = '.\MultiFighter.dll'     # 调用的模型路径，若加载失败，可改为绝对路径
        # 仿真设定
        self.epoch_max = 1              # 仿真轮次
        self.len_max = 12000         # 单轮仿真长度
        self.originLongitude = 160.123456   # 仿真的经纬度原点位置
        self.originLatitude = 24.8976763

        # ———————————————————————————— 对抗双方的初始状态 ————————————————————————————
        # 依次设定蓝0，蓝1，红0，红1四架飞机的初始设置

        # 初始位置（北东地）
        self.NED = []
        for i in range(2):
            self.NED.append([10000 + 5000 * i, 0, -10000])
        for i in range(2):
            self.NED.append([10000 + 5000 * i, 30000, -10000])
        # 初始速度（马赫数）
        self.ma = []
        for i in range(4):
            self.ma.append(1.2)

        # 初始航向（0度为北向）
        self.orientation = []
        for i in range(2):
            self.orientation.append(90)
        for i in range(2):
            self.orientation.append(-90)

        # 设置控制模式
        self.control_mode = []
        for i in range(4):
            self.control_mode.append(3)



class FighterDataIn(object):
    def __init__(self):
        # 直接控制输入,依据操作模式代表不同含义
        # 控制模式3：[油门， 期望机体法向过载， 期望机体滚转速率， 无意义补充位]
        # 控制模式0：[油门， 纵向杆， 横向杆， 方向舵]
        self.control_mode = 3
        self.control_input = [1, 1/9, 0, 0]
        # 航炮开火指令，1为发射，0为不发射
        self.fire = 0

        # 机载雷达锁定目标，机载雷达中，蓝色机编号依次为0,1，红色机编号为2,3
        self.target_index = 0

        # 导弹开火指令，1为发射，0为不发射
        self.missile_fire = 0         # 近距弹发射
