from basic.simulation_env import CombatEnv
from SimArg import InitialData, FighterDataIn

if __name__ == '__main__':
    # ##################### 初始化设定 ########################
    # 初始化环境与输入量
    data_initial = InitialData()
    datain = [FighterDataIn() for m in range(4)]
    env = CombatEnv(data_initial)

    ####################### 开始多轮仿真 #######################
    for i_episode in range(data_initial.epoch_max):
        # 重置仿真
        data_output = env.reset(data_initial)
        # ###################### 开始单轮仿真 ######################
        for t in range(data_initial.len_max):
            # 打印数据
            print('\n仿真步长：', t, '仿真时间： ', t * 0.05)
            # —————————————————————————————————— 编辑输入控制数据 ——————————————————————————————————————
            for i in range(4):
                # 飞机控制模式
                datain[i].control_mode = 3

                # 控制输入量
                datain[i].control_input = [1, 1 / 9, 0, 0]

                # 目标编号输入量
                if i < 2:
                    datain[i].target_index = i + 2
                else:
                    datain[i].target_index = i - 2

                # 导弹及航炮控制指令
                if t > 1:
                    datain[i].missile_fire = 1
                    datain[i].fire = 1
                else:
                    datain[i].missile_fire = 0
                    datain[i].fire = 0

                # 打印输出数据
                print('data_output', data_output[i].selfdata.MachNumber)

            # 单个回合更新
            terminal, data_output = env.update(datain)

            # 仿真结束
            if terminal >= 0:
                print("Episode: \t{} ,episode len is: \t{}".format(i_episode, t))
                print(terminal)
                break
