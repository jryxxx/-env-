import math

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from basic.TCPclient import TcpClient
import time
import random

# 定义 DQN 模型
class DQN(nn.Module):
    def __init__(self, state_size, action_size):
        super(DQN, self).__init__()
        self.fc1 = nn.Linear(state_size, 128)
        self.fc2 = nn.Linear(128, 128)
        self.fc3 = nn.Linear(128, action_size)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)

# 定义经验回放池
class ReplayBuffer:
    def __init__(self, buffer_size):
        self.buffer = []
        self.buffer_size = buffer_size

    def add(self, experience):
        if len(self.buffer) >= self.buffer_size:
            self.buffer.pop(0)
        self.buffer.append(experience)

    def sample(self, batch_size):
        return random.sample(self.buffer, batch_size)
def is_in_protected_zone(longitude, latitude, altitude, center_longitude, center_latitude, radius, min_altitude, max_altitude):
    R = 6371000.0  # 地球半径（公里）
    lon1, lat1 = map(math.radians, [longitude, latitude])
    lon2, lat2 = map(math.radians, [center_longitude, center_latitude])
    horizontal_distance = R * math.acos(
        math.sin(lat1) * math.sin(lat2) +
        math.cos(lat1) * math.cos(lat2) * math.cos(lon1 - lon2)
    )
    in_horizontal_range = horizontal_distance <= radius
    in_altitude_range = min_altitude <= altitude <= max_altitude
    return in_horizontal_range and in_altitude_range
# 初始化 TCP 通信
TCP_client = TcpClient(port=42674)
TCP_client.listen_start()
output0 = TCP_client.simdata0
output1 = TCP_client.simdata1

# 参数设置
state_size = 10  # 状态向量长度
action_size = 12  # 动作空间大小
gamma = 0.99  # 折扣因子
epsilon = 1.0  # 探索概率
epsilon_decay = 0.995
min_epsilon = 0.01
buffer_size = 10000  # 经验回放池大小
batch_size = 64  # 批量大小
learning_rate = 0.001  # 学习率

# 初始化网络和优化器
policy_net = DQN(state_size, action_size)
target_net = DQN(state_size, action_size)
target_net.load_state_dict(policy_net.state_dict())
target_net.eval()
optimizer = optim.Adam(policy_net.parameters(), lr=learning_rate)
loss_fn = nn.MSELoss()

# 初始化经验回放池
replay_buffer = ReplayBuffer(buffer_size)

# 状态提取函数
def get_state(output):
    # 获取敌机1信息
    target1_distance = output.radardata.target1_Distance   # 默认值为较大距离
    print(f"敌机距离为：{target1_distance}")
    target1_azi_angle = output.radardata.target1_AziAngle
    target1_ele_angle = output.radardata.target1_EleAngle
    target1_survive = float(output.statedata.target1_Survive)

    # 获取敌机2信息
    target2_distance = output.radardata.target2_Distance
    target2_azi_angle = output.radardata.target2_AziAngle
    target2_ele_angle = output.radardata.target2_EleAngle
    target2_survive = float(output.statedata.target2_Survive)

    # 获取导弹告警信息
    missile_alert_num = output.alertdata.emergency_missile_num
    missile_alert_angle = output.alertdata.emergency_missile_AziAngle

    # 处理导弹告警数量（取列表长度或默认0）
    if isinstance(missile_alert_num, list):
        missile_alert_num = len(missile_alert_num)  # 统计导弹数量
    missile_alert_num = missile_alert_num or 0  # 如果为空，设置为0

    # 处理导弹告警方位角（取第一个角度或默认0）
    if isinstance(missile_alert_angle, list):
        missile_alert_angle = missile_alert_angle[0] if missile_alert_angle else 0
    missile_alert_angle = missile_alert_angle or 0

    # 返回状态数组
    return np.array([
        float(target1_distance), float(target1_azi_angle), float(target1_ele_angle), target1_survive,
        float(target2_distance), float(target2_azi_angle), float(target2_ele_angle), target2_survive,
        float(missile_alert_num), float(missile_alert_angle)
    ], dtype=np.float32)


# 奖励函数
def calculate_reward(output, action):
    """
    计算奖励值，综合考虑安全性、任务完成度和有效性。
    """
    reward = 0
    # 0 飞机生存信息

    # 1. 是否在目标点，目标点奖励，不在大量惩罚** 他不会自己逼近，更改惩罚机制，判断他和目标纬度的距离
    altitude = output.selfdata.Altitude
    longitude = output.selfdata.Longitude
    latitude = output.selfdata.Latitude
    in_protected_zone = is_in_protected_zone(
        longitude, latitude, altitude,
        center_longitude=160.098,
        center_latitude=24.88,
        radius=10000,
        min_altitude=0,
        max_altitude=12000
    )
    reward -= (longitude-160.098)*8
    reward += 8-((longitude - 160.098) * 8)
    reward -= (latitude - 24.88) * 8
    reward += 8 - ((latitude - 24.88) * 8)
    # if not in_protected_zone:
    #     print("不在目标区域")
    #     reward -= 4  # 在保护区外，惩罚
    #     reward -= 0
    # else:
    #     print("在目标区域")
    #     reward += 3
    #2 .导弹命中奖励 导弹失效惩罚
    if (output.selfdata.Missile1State == 2 or output.selfdata.Missile2State == 2):
        reward += 10
    if (output.selfdata.Missile3State == 2 or output.selfdata.Missile4State == 2):
        reward += 8
    if (output.selfdata.Missile1State == 3 or output.selfdata.Missile2State == 3):
        reward -= 4
    if (output.selfdata.Missile3State == 3 or output.selfdata.Missile4State == 3):
        reward -= 4
    #3. 追踪目标，接近敌机奖励，雷达距离40000米
    if (output.radardata.target1_Distance > 0): #防止没有检测到飞机为0
        reward += max(0, 40000 - output.radardata.target1_Distance)/1000  # 与敌机1距离奖励（远离时奖励减少）
    if (output.radardata.target2_Distance > 0):
        reward += max(0, 40000 - output.radardata.target2_Distance)/1000  # 与敌机2距离奖励
    #4 导弹躲避失败惩罚
    if output.alertdata.emergency_missile_num > 0 and action != 4:
        reward -= 8  # 未规避导弹，强烈惩罚
    #5 ##友机碰撞惩罚 ** 远离友军 防止导弹误伤
    friend_distance = output.radardata.friend_Distance  # 单位：米
    SAFE_DISTANCE = 200  # 安全距离（单位：米）
    WARNING_DISTANCE = 900  # 警告距离（单位：米）
    #如果距离小于安全距离，视为碰撞，给予强烈惩罚
    if friend_distance < SAFE_DISTANCE:
        reward -= 7  # 碰撞强烈惩罚
    elif friend_distance < WARNING_DISTANCE:
        reward -= 3  # 距离过近给予轻微惩罚
    # altitude = output.selfdata.Altitude
    # if altitude < 3600:
    #     reward -= 5  # 低于最低高度，强烈惩罚
    # elif altitude < 5000:
    #     reward -= 3  # 较低高度，轻微惩罚
    # elif altitude > 12000:
    #     reward -= 2  # 高度过高，轻微惩罚
    # else:
    #     reward += 1  # 安全高度内，奖励
    # print(f"奖励值计算：{reward}")
    return reward

# 动作解释函数
def action_to_input(action):
    target1_index = output0.radardata.target1_Index
    target1_ele_angle = output0.radardata.target1_EleAngle
    target1_azi_angle = output0.radardata.target1_AziAngle
    target1_distance = output0.radardata.target1_Distance

    target2_index = output1.radardata.target2_Index
    target2_ele_angle = output1.radardata.target2_EleAngle
    target2_azi_angle = output1.radardata.target2_AziAngle
    target2_distance = output1.radardata.target2_Distance
    if action == 0:  # 保持当前航向
        return [0.3, 1 / 9, 0, 0, 0, 0, 0, 3]  # 油门0.5，低功耗巡航
    elif action == 1:  # 航炮开火
        return [0.8, 1 / 9, 0, 0, 0, 0, 0, 3]
    elif action == 2:  # 发射导弹（目标1）
        if target1_distance < 3000 :
            return [0.8, 1 / 9, 0, 0, 0, 0, 1, 3]
        else:
            return [1, 1 / 9, 0, 0, 0, 0, 0, 3]
    elif action == 3:  # 发射导弹（目标2）
        if target2_distance < 3000:
            return [0.8, 1 / 9, 0, 0, 1, 0, 1, 3]
        else:
            return [1, 1 / 9, 0, 0, 1, 0, 0, 3]
    elif action == 4:  # 规避导弹
        return [1, 1, 0, 0, 0, 0, 0, 3]
    elif action == 5:  # 接近敌机1
        if target1_distance > 0:
            ele_action = target1_ele_angle / 150  # 将高低角归一化处理
            azi_action = target1_azi_angle / 150  # 将方位角归一化处理
            print(f"追踪敌机1 - 编号: {target1_index}, 距离: {target1_distance} 米, 高低角: {target1_ele_angle}, 方位角: {target1_azi_angle}")
            return [0.8, ele_action, azi_action, 0, 0, 0, 0, 3]
        else:
            return [0.8, 0.2, 0, 0, 0, 0, 0, 3]
    elif action == 6:  # 接近敌机2
        if target2_distance > 0:
            ele_action = target2_ele_angle / 150  # 将高低角归一化处理
            azi_action = target2_azi_angle / 150  # 将方位角归一化处理
            print(f"追踪敌机1 - 编号: {target2_index}, 距离: {target2_distance} 米, 高低角: {target2_ele_angle}, 方位角: {target2_azi_angle}")
            return [0.8, ele_action, azi_action, 0, 1, 0, 0, 3]
        else:
            return [0.8, 0.2, 0, 0, 1, 0, 0, 3]

    elif action == 7:  # 节省燃油直行
        return [0.3, 0, 0, 0, 1, 0, 0, 3]  # 油门0.3，低油耗保持直行
    elif action == 8:  # 左摆头上升追踪
        return [0.8, 1/9+0.2, 0.3, 0, 0, 0, 0, 3]
    elif action == 9:  # 右摆头上升追踪
        return [0.8, 1/9+0.2, -0.3, 0, 1, 0, 0, 3]
    elif action == 10:  # 左白头下降追踪
        return [0.8, 1/9-0.2, 0.3, 0, 0, 0, 0, 3]
    elif action == 11:  # 右摆头下降追踪
        return [0.8, 1/9-0.2, -0.3, 0, 1, 0, 0, 3]

# 检查飞行状态是否安全
def check_safety(output):
    """
    根据飞行状态数据检查飞机是否在安全范围内。
    如果不安全，返回纠正动作；否则返回 None。
    """
    # 提取本机状态
    altitude = output.selfdata.Altitude
    ground_speed = output.selfdata.GroundSpeed
    fuel = output.selfdata.NumberofFuel
    normal_load = output.selfdata.LongitudeinalLoad
    blood = output.selfdata.left_bloods
    altitude = output.selfdata.Altitude
    roll_angle = output.selfdata.RollAngle
    pitch_angle = output.selfdata.PitchAngle
    # 安全阈值
    MIN_ALTITUDE = 3500  # 最低飞行高度（米）
    MIN_SPEED = 50  # 最低地速（米/秒）
    MAX_LOAD = 0.9  # 最大过载（g）

    # 检查最低飞行高度
    if altitude < MIN_ALTITUDE:
        print(f"警告：高度过低！调整为安全高度：{altitude}")
        print(f"现在pitch_angle为：{pitch_angle}")
        if pitch_angle > 60:
            g_force = 0
        else:
            g_force = min(1.0, (MIN_ALTITUDE - altitude) / 2000)  # 根据高度差动态调整法向过载（最大值为1.0）
        throttle = min(1.0, 0.8 + (MIN_ALTITUDE - altitude) / 5000)  # 根据高度差动态调整油门
        return [throttle, g_force, 0, 0, 0, 0, 0, 3]  # 提升高度，调整姿态

    # # 检查速度
    # if ground_speed < MIN_SPEED:
    #     print(f"警告：速度过低！增加油门：{ground_speed}")
    #     return [1, 1 / 9, 0, 0, 0, 0, 0, 3]  # 增加推力以提高速度

    # # 检查剩余燃料
    # if fuel <= 0:
    #     print("警告：燃料耗尽！无法继续飞行。")
    #     return [0.3, 0, 0, 0, 0, 0, 0, 3]  # 低油耗模式

    # 检查过载
    # if abs(normal_load) > MAX_LOAD:
    #     print(f"警告：过载超出限制！当前过载：{normal_load}")
    #     return [1, -0.2, 0, 0, 0, 0, 0, 3]  # 减缓动作以降低过载


    # 如果状态安全，返回 None
    return None

# 主循环
while True:
    time.sleep(0.005)

    # 获取当前状态
    state0 = get_state(output0)
    state1 = get_state(output1)

    # 检查是否有敌机
    has_enemy0 = state0[0]
    has_enemy1 = state1[0]


    # epsilon-greedy 策略选择动作
    if not has_enemy0:
        action0 = 0  # 未检测到敌机，保持直行
    elif np.random.rand() <= epsilon:
        action0 = np.random.randint(0, action_size)
    else:
        with torch.no_grad():
            action0 = torch.argmax(policy_net(torch.FloatTensor(state0))).item()

    if not has_enemy1:
        action1 = 2  # 未检测到敌机，保持直行
    elif np.random.rand() <= epsilon:
        action1 = np.random.randint(0, action_size)
    else:
        with torch.no_grad():
            action1 = torch.argmax(policy_net(torch.FloatTensor(state1))).item()

    # 动作范围断言
    assert 0 <= action0 < action_size, f"Action0 out of bounds: {action0}"
    assert 0 <= action1 < action_size, f"Action1 out of bounds: {action1}"
# 动作输入转换
    datain0 = action_to_input(action0)
    datain1 = action_to_input(action1)
    # # 检查安全性
    safety_action0 = check_safety(output0)
    safety_action1 = check_safety(output1)
    if safety_action0:
        TCP_client.send_data(safety_action0, datain1)
        continue
    if safety_action1:
        TCP_client.send_data(datain0, safety_action1)
        # time.sleep(0.5)
        # TCP_client.send_data(datain0, [1, 1 / 9, 0, 0, 0, 0, 0, 3])
        # time.sleep(0.5)
        continue
    # 动作输入转换

    # 执行动作
    TCP_client.send_data(datain0, datain1)

    # 获取奖励和下一状态
    reward0 = calculate_reward(output0, action0)
    reward1 = calculate_reward(output1, action1)
    next_state0 = get_state(output0)
    next_state1 = get_state(output1)

    # 存储经验
    replay_buffer.add((state0, action0, reward0, next_state0))
    replay_buffer.add((state1, action1, reward1, next_state1))

    # 从经验池中采样训练
    if len(replay_buffer.buffer) >= batch_size:
        batch = replay_buffer.sample(batch_size)
        states, actions, rewards, next_states = zip(*batch)

        states = torch.FloatTensor(np.array(states))
        actions = torch.LongTensor(actions).unsqueeze(1)
        rewards = torch.FloatTensor(rewards).unsqueeze(1)
        next_states = torch.FloatTensor(np.array(next_states))

        # 当前 Q 值
        q_values = policy_net(states).gather(1, actions)

        # 目标 Q 值
        with torch.no_grad():
            next_q_values = target_net(next_states).max(1)[0].unsqueeze(1)
            target_q_values = rewards + gamma * next_q_values

        # 更新网络
        loss = loss_fn(q_values, target_q_values)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    # 更新目标网络
    if random.random() < 0.01:
        target_net.load_state_dict(policy_net.state_dict())

    # 减少探索率
    if epsilon > min_epsilon:
        epsilon *= epsilon_decay

    # 打印调试信息
    print(f'Aircraft 0: Action={action0}, Reward={reward0}')
    print(f'Aircraft 1: Action={action1}, Reward={reward1}')
