# -*- coding: utf-8 -*-
# @Time    : 2024/11/21 10:27
# @Author  : Ruiyang Jia
# @FileName: red.py
# @Software: PyCharm


import time

from basic.TCPclient import TcpClient


class AirCombat:
    """
    空中对抗类实现
    :param uav: 飞机编号
    :param uav_selfdata: 自身信息
    :param uav_radardata: 雷达信息
    :param uav_statedata: 状态信息
    :param uav_closedata: 近战信息
    :param uav_alertdata: 告警信息
    :param uav_action: 飞机动作
    :param combat_strategy: 战斗策略
    :param expected_altitude: 期望高度
    """

    def __init__(self):
        self.uav = {
            "uav1": 1,
            "uav2": 2
        }
        self.uav_selfdata = {
            "uav1": [0] * 40,
            "uav2": [0] * 40
        }
        for uav in self.uav.keys():  # 初始化飞机高度
            self.uav_selfdata[uav][7] = 10000
        self.uav_radardata = {
            "uav1": [0] * 20,
            "uav2": [0] * 20
        }
        self.uav_statedata = {
            "uav1": [0] * 14,
            "uav2": [0] * 14
        }
        self.uav_closedata = {
            "uav1": [0] * 11,
            "uav2": [0] * 11
        }
        self.uav_alertdata = {
            "uav1": [0] * 6,
            "uav2": [0] * 6
        }
        self.uav_action = {
            "uav1": [0] * 8,
            "uav2": [0] * 8
        }
        self.limit_altitude = 4000

    def get_data(self, output1, output2):
        """
        飞机信息
        :param output1: 飞机 1 信息
        :param output2: 飞机 2 信息
        :return: self.uav_selfdata: 自身信息
        :return: self.uav_radardata: 雷达信息
        :return: self.uav_statedata: 状态信息
        :return: self.uav_closedata: 近战信息
        :return: self.uav_alertdata: 告警信息
        :return: True
        """
        output = [output1, output2]
        for uav in self.uav.keys():
            temp_selfdata = output[self.uav[uav] - 1].selfdata
            self.uav_selfdata[uav] = [
                temp_selfdata.fighter_side,  # 阵营 0
                temp_selfdata.control_mode,  # 控制模式 1
                temp_selfdata.left_bullet,  # 剩余航炮弹药量 2
                temp_selfdata.left_missile,  # 剩余导弹数量 3
                temp_selfdata.left_bloods,  # 剩余生命值 4
                temp_selfdata.Longitude,  # 经度 (度) 5
                temp_selfdata.Latitude,  # 纬度 (度) 6
                temp_selfdata.Altitude,  # 高度 (米) 7
                temp_selfdata.NorthVelocity,  # 北速度 (米/秒) 8
                temp_selfdata.EastVelocity,  # 东速度 (米/秒) 9
                temp_selfdata.VerticalVelocity,  # 垂直速度 (米/秒) 10
                temp_selfdata.NorthAcceleration,  # 北加速度 (米/秒^2) 11
                temp_selfdata.EastAcceleration,  # 东加速度 (米/秒^2) 12
                temp_selfdata.VerticalAcceleration,  # 垂直加速度 (米/秒^2) 13
                temp_selfdata.RollAngle,  # 体轴姿态角 (度) 14
                temp_selfdata.PitchAngle,  # 体轴姿态角 (度) 15
                temp_selfdata.YawAngle,  # 体轴姿态角 (度) 16
                temp_selfdata.PathPitchAngle,  # 航迹角 (度) 17
                temp_selfdata.PathYawAngle,  # 航迹角 (度) 18
                temp_selfdata.AttackAngle,  # 攻角 (度) 19
                temp_selfdata.SideslipAngle,  # 侧滑角 (度) 20
                temp_selfdata.RollRate,  # 体轴姿态角速度 (度/秒) 21
                temp_selfdata.PitchRate,  # 体轴姿态角速度 (度/秒) 22
                temp_selfdata.YawRate,  # 体轴姿态角速度 (度/秒) 23
                temp_selfdata.NormalLoad,  # 体轴法向过载 (g) 24
                temp_selfdata.LateralLoad,  # 体轴侧向过载 (g) 25
                temp_selfdata.LongitudeinalLoad,  # 体轴纵向过载 (g) 26
                temp_selfdata.NormalVelocity,  # 体轴法向加速度 (米/秒^2) 27
                temp_selfdata.LateralVelocity,  # 体轴侧向加速度 (米/秒^2) 28
                temp_selfdata.LongitudianlVelocity,  # 体轴纵向加速度 (米/秒^2) 29
                temp_selfdata.TrueAirSpeed,  # 真空速 (米/秒) 30
                temp_selfdata.IndicatedAirSpeed,  # 指示空速 (米/秒) 31
                temp_selfdata.GroundSpeed,  # 地速 (米/秒) 32
                temp_selfdata.MachNumber,  # 马赫数 33
                temp_selfdata.NumberofFuel,  # 剩余油量 (kg) 34
                temp_selfdata.Thrust,  # 推力 (N) 35
                temp_selfdata.Missile1State,  # 导弹状态 (0: 未发射, 1: 飞行中, 2: 命中, 3: 失效) 36
                temp_selfdata.Missile2State,  # 导弹状态 (0: 未发射, 1: 飞行中, 2: 命中, 3: 失效) 37
                temp_selfdata.Missile3State,  # 导弹状态 (0: 未发射, 1: 飞行中, 2: 命中, 3: 失效) 38
                temp_selfdata.Missile4State  # 导弹状态 (0: 未发射, 1: 飞行中, 2: 命中, 3: 失效) 39
            ]

            temp_radardata = output[self.uav[uav] - 1].radardata
            self.uav_radardata[uav] = [
                temp_radardata.friend_EleAngle,  # 友机高低角（度） 0
                temp_radardata.friend_AziAngle,  # 友机方位角（度） 1
                temp_radardata.friend_Distance,  # 友机距离（米） 2
                temp_radardata.friend_NorthVelocity,  # 友机北速度（米/秒） 3
                temp_radardata.friend_EastVelocity,  # 友机东速度（米/秒） 4
                temp_radardata.friend_VerticalVelocity,  # 友机地速度（米/秒） 5
                temp_radardata.target1_Index,  # 敌机 1 编号 6
                temp_radardata.target1_EleAngle,  # 敌机 1 高低角（度） 7
                temp_radardata.target1_AziAngle,  # 敌机 1 方位角（度） 8
                temp_radardata.target1_Distance,  # 敌机 1 距离（米） 9
                temp_radardata.target1_NorthVelocity,  # 敌机 1 北速度（米/秒） 10
                temp_radardata.target1_EastVelocity,  # 敌机 1 东速度（米/秒） 11
                temp_radardata.target1_VerticalVelocity,  # 敌机 1 地速度（米/秒） 12
                temp_radardata.target2_Index,  # 敌机 2 编号 13
                temp_radardata.target2_EleAngle,  # 敌机 2 高低角（度） 14
                temp_radardata.target2_AziAngle,  # 敌机 2 方位角（度） 15
                temp_radardata.target2_Distance,  # 敌机 2 距离（米） 16
                temp_radardata.target2_NorthVelocity,  # 敌机 2 北速度（米/秒） 17
                temp_radardata.target2_EastVelocity,  # 敌机 2 东速度（米/秒） 18
                temp_radardata.target2_VerticalVelocity  # 敌机 2 地速度（米/秒） 19
            ]

            temp_statedata = output[self.uav[uav] - 1].statedata
            self.uav_statedata[uav] = [
                temp_statedata.friend_Longitude,  # 友机经度 (度) 0
                temp_statedata.friend_Latitude,  # 友机纬度 (度) 1
                temp_statedata.friend_Altitude,  # 友机高度 (米) 2
                temp_statedata.friend_Survive,  # 友机是否存活 (BOOL) 3
                temp_statedata.target1_Index,  # 敌机 1 编号 4
                temp_statedata.target1_Longitude,  # 敌机 1 经度 (度) 5
                temp_statedata.target1_Latitude,  # 敌机 1 纬度 (度) 6
                temp_statedata.target1_Altitude,  # 敌机 1 高度 (米) 7
                temp_statedata.target1_Survive,  # 敌机 1 是否存活 (BOOL) 8
                temp_statedata.target2_Index,  # 敌机 2 编号 9
                temp_statedata.target2_Longitude,  # 敌机 2 经度 (度) 10
                temp_statedata.target2_Latitude,  # 敌机 2 纬度 (度) 11
                temp_statedata.target2_Altitude,  # 敌机 2 高度 (米) 12
                temp_statedata.target2_Survive  # 敌机 2 是否存活 (BOOL) 13
            ]

            temp_closedata = output[self.uav[uav] - 1].closedata
            self.uav_closedata[uav] = [
                temp_closedata.friend_EleAngle,  # 友机高低角 (度) 0
                temp_closedata.friend_AziAngle,  # 友机方位角 (度) 1
                temp_closedata.friend_Distance,  # 友机距离 (米) 2
                temp_closedata.target1_Index,  # 敌机 1 编号 3
                temp_closedata.target1_EleAngle,  # 敌机 1 高低角 (度) 4
                temp_closedata.target1_AziAngle,  # 敌机 1 方位角 (度) 5
                temp_closedata.target1_Distance,  # 敌机 1 距离 (米) 6
                temp_closedata.target2_Index,  # 敌机 2 编号 7
                temp_closedata.target2_EleAngle,  # 敌机 2 高低角 (度) 8
                temp_closedata.target2_AziAngle,  # 敌机 2 方位角 (度) 9
                temp_closedata.target2_Distance  # 敌机 2 距离 (米) 10
            ]

            temp_alertdata = output[self.uav[uav] - 1].alertdata
            self.uav_alertdata[uav] = [
                temp_alertdata.emergency_num,  # 飞机告警数量 0
                temp_alertdata.emergency_EleAngle,  # 飞机高低角 (度) 1
                temp_alertdata.emergency_AziAngle,  # 飞机方位角 (度) 2
                temp_alertdata.emergency_missile_num,  # 导弹告警数量 3
                temp_alertdata.emergency_missile_EleAngle,  # 导弹高低角 (度) 4
                temp_alertdata.emergency_missile_AziAngle  # 导弹方位角 (度) 5
            ]

        return True

    @staticmethod
    def init_altitude():
        """
        :return:
        """
        print("初始化 : 飞机高度!!!")
        datain0 = [0.8, 1 / 9 + 0.6, 0, 0, 0, 0, 0, 3]
        datain1 = [0.5, 1 / 9, 0, 0, 0, 0, 0, 3]
        TCP_client.send_data(datain0, datain1)
        time.sleep(0.3)
        return True

    def init_action(self):
        """
        :return:
        """
        print("初始化 : 飞机动作!!!")
        for uav in self.uav.keys():
            self.uav_action[uav] = [0.5, 1 / 9, 0, 0, 0, 0, 0, 3]
        return True

    # def low_altitude(self, datain0, datain1):
    #     """
    #
    #     :return:
    #     """
    #     if self.uav_selfdata["uav1"][7] < self.limit_altitude < self.uav_selfdata["uav2"][7]:
    #         if self.uav_radardata["uav1"][9] < self.uav_radardata["uav1"][16]:
    #             if self.uav_radardata["uav1"][9] < 10000:
    #                 datain0 = [1, 0.8, 0, 0, 0, 1, 1, 3]
    #             else:
    #                 datain0 = [1, 0.8, 0, 0, 0, 0, 0, 3]
    #         else:
    #             if self.uav_radardata["uav1"][16] < 10000:
    #                 datain0 = [1, 0.8, 0, 0, 1, 1, 1, 3]
    #             else:
    #                 datain0 = [1, 0.8, 0, 0, 0, 0, 0, 3]
    #     elif self.uav_selfdata["uav1"][7] > self.limit_altitude > self.uav_selfdata["uav2"][7]:
    #         if self.uav_radardata["uav2"][9] < self.uav_radardata["uav2"][16]:
    #             if self.uav_radardata["uav2"][9] < 10000:
    #                 datain1 = [1, 0.8, 0, 0, 0, 1, 1, 3]
    #             else:
    #                 datain1 = [1, 0.8, 0, 0, 0, 0, 0, 3]
    #         else:
    #             if self.uav_radardata["uav2"][16] < 10000:
    #                 datain1 = [1, 0.8, 0, 0, 1, 1, 1, 3]
    #             else:
    #                 datain1 = [1, 0.8, 0, 0, 0, 0, 0, 3]
    #     elif self.uav_selfdata["uav1"][7] < self.limit_altitude and self.uav_selfdata["uav2"][7] < self.limit_altitude:
    #         if self.uav_radardata["uav1"][9] < self.uav_radardata["uav1"][16]:
    #             if self.uav_radardata["uav1"][9] < 10000:
    #                 datain0 = [1, 0.8, 0, 0, 0, 1, 1, 3]
    #             else:
    #                 datain0 = [1, 0.8, 0, 0, 0, 0, 0, 3]
    #         else:
    #             if self.uav_radardata["uav1"][16] < 10000:
    #                 datain0 = [1, 0.8, 0, 0, 1, 1, 1, 3]
    #             else:
    #                 datain0 = [1, 0.8, 0, 0, 0, 0, 0, 3]
    #         if self.uav_radardata["uav2"][9] < self.uav_radardata["uav2"][16]:
    #             if self.uav_radardata["uav2"][9] < 10000:
    #                 datain1 = [1, 0.8, 0, 0, 0, 1, 1, 3]
    #             else:
    #                 datain1 = [1, 0.8, 0, 0, 0, 0, 0, 3]
    #         else:
    #             if self.uav_radardata["uav2"][16] < 10000:
    #                 datain1 = [1, 0.8, 0, 0, 1, 1, 1, 3]
    #             else:
    #                 datain1 = [1, 0.8, 0, 0, 0, 0, 0, 3]
    #     TCP_client.send_data(datain0, datain1)
    #     time.sleep(0.3)  # 0.5 导致循环
    #     return True

    def low_altitude(self, datain0, datain1):
        """

        :return:
        """
        if self.uav_selfdata["uav1"][7] < self.limit_altitude < self.uav_selfdata["uav2"][7]:
            datain0 = [1, 0.8, 0, 0, 0, 0, 0, 3]
        elif self.uav_selfdata["uav1"][7] > self.limit_altitude > self.uav_selfdata["uav2"][7]:
            datain1 = [1, 0.8, 0, 0, 0, 0, 0, 3]
        elif self.uav_selfdata["uav1"][7] < self.limit_altitude and self.uav_selfdata["uav2"][7] < self.limit_altitude:
            datain0 = [1, 0.8, 0, 0, 0, 0, 0, 3]
            datain1 = [1, 0.8, 0, 0, 0, 0, 0, 3]
        TCP_client.send_data(datain0, datain1)
        time.sleep(0.3)  # 0.5 导致循环
        return True

    def avoid_missile(self, datain0, datain1):
        """

        :return:
        """
        print(f"紧急状态 2 数值 {self.uav_alertdata['uav1'][4]} {self.uav_alertdata['uav2'][5]}")
        if self.uav_alertdata["uav1"][3] > 0:
            if self.uav_alertdata["uav1"][4][0] > 0 and self.uav_alertdata["uav1"][5][0] > 0:
                datain0 = [1, 1 / 9 - 0.2, -0.2, 0, 0, 0, 0, 3]
            elif self.uav_alertdata["uav1"][4][0] > 0 > self.uav_alertdata["uav1"][5][0]:
                datain0 = [1, 1 / 9 - 0.2, 0.2, 0, 0, 0, 0, 3]
            elif self.uav_alertdata["uav1"][4][0] < 0 < self.uav_alertdata["uav1"][5][0]:
                datain0 = [1, 1 / 9 + 0.2, -0.2, 0, 0, 0, 0, 3]
            elif self.uav_alertdata["uav1"][4][0] < 0 and self.uav_alertdata["uav1"][5][0] < 0:
                datain0 = [1, 1 / 9 + 0.2, 0.2, 0, 0, 0, 0, 3]
        if self.uav_alertdata["uav2"][3] > 0:
            if self.uav_alertdata["uav2"][4][0] > 0 and self.uav_alertdata["uav2"][5][0] > 0:
                datain1 = [1, 1 / 9 - 0.2, -0.2, 0, 0, 0, 0, 3]
            elif self.uav_alertdata["uav2"][4][0] > 0 > self.uav_alertdata["uav2"][5][0]:
                datain1 = [1, 1 / 9 - 0.2, 0.2, 0, 0, 0, 0, 3]
            elif self.uav_alertdata["uav2"][4][0] < 0 < self.uav_alertdata["uav2"][5][0]:
                datain1 = [1, 1 / 9 + 0.2, -0.2, 0, 0, 0, 0, 3]
            elif self.uav_alertdata["uav2"][4][0] < 0 and self.uav_alertdata["uav2"][5][0] < 0:
                datain1 = [1, 1 / 9 + 0.2, 0.2, 0, 0, 0, 0, 3]
        TCP_client.send_data(datain0, datain1)
        time.sleep(0.3)
        return True

    def attack_target(self, datain0, datain1):
        """

        :return:
        """
        print(f"uav 1 敌机距离 : {self.uav_radardata['uav1'][9]} {self.uav_radardata['uav1'][16]}")
        print(f"uav 2 敌机距离 : {self.uav_radardata['uav2'][9]} {self.uav_radardata['uav2'][16]}")
        if self.uav_radardata["uav1"][9] > 0 and self.uav_radardata["uav1"][16] > 0:
            if self.uav_radardata["uav1"][9] < self.uav_radardata["uav1"][16]:
                ele_action = self.uav_radardata["uav1"][7] / 150
                azi_action = self.uav_radardata["uav1"][8] / 150
                datain0 = [1, ele_action, azi_action, 0, 0, 0, 0, 3]
                if self.uav_radardata["uav1"][9] < 8000:
                    datain0 = [0.6, ele_action, azi_action, 0, 0, 1, 1, 3]
            else:
                ele_action = self.uav_radardata["uav1"][14] / 150
                azi_action = self.uav_radardata["uav1"][15] / 150
                datain0 = [1, ele_action, azi_action, 0, 0, 0, 0, 3]
                if self.uav_radardata["uav1"][16] < 8000:
                    datain0 = [0.6, ele_action, azi_action, 0, 1, 1, 1, 3]
        elif self.uav_radardata["uav1"][9] > 0 and self.uav_radardata["uav1"][16] == 0:
            ele_action = self.uav_radardata["uav1"][7] / 150
            azi_action = self.uav_radardata["uav1"][8] / 150
            datain0 = [1, ele_action, azi_action, 0, 0, 0, 0, 3]
            if self.uav_radardata["uav1"][9] < 8000:
                datain0 = [0.6, ele_action, azi_action, 0, 0, 1, 1, 3]
        elif self.uav_radardata["uav1"][9] == 0 and self.uav_radardata["uav1"][16] > 0:
            ele_action = self.uav_radardata["uav1"][14] / 150
            azi_action = self.uav_radardata["uav1"][15] / 150
            datain0 = [1, ele_action, azi_action, 0, 0, 0, 0, 3]
            if self.uav_radardata["uav1"][16] < 8000:
                datain0 = [0.6, ele_action, azi_action, 0, 1, 1, 1, 3]
        if self.uav_radardata["uav2"][9] > 0 and self.uav_radardata["uav2"][16] > 0:
            if self.uav_radardata["uav2"][9] < self.uav_radardata["uav2"][16]:
                ele_action = self.uav_radardata["uav2"][7] / 150
                azi_action = self.uav_radardata["uav2"][8] / 150
                datain1 = [1, ele_action, azi_action, 0, 0, 0, 0, 3]
                if self.uav_radardata["uav2"][9] < 8000:
                    datain1 = [0.6, ele_action, azi_action, 0, 0, 1, 1, 3]
            else:
                ele_action = self.uav_radardata["uav2"][14] / 150
                azi_action = self.uav_radardata["uav2"][15] / 150
                datain1 = [1, ele_action, azi_action, 0, 0, 0, 0, 3]
                if self.uav_radardata["uav2"][16] < 8000:
                    datain1 = [0.6, ele_action, azi_action, 0, 1, 1, 1, 3]
        elif self.uav_radardata["uav2"][9] > 0 and self.uav_radardata["uav2"][16] == 0:
            ele_action = self.uav_radardata["uav2"][7] / 150
            azi_action = self.uav_radardata["uav2"][8] / 150
            datain1 = [1, ele_action, azi_action, 0, 0, 0, 0, 3]
            if self.uav_radardata["uav2"][9] < 8000:
                datain1 = [0.6, ele_action, azi_action, 0, 0, 1, 1, 3]
        elif self.uav_radardata["uav2"][9] == 0 and self.uav_radardata["uav2"][16] > 0:
            ele_action = self.uav_radardata["uav2"][14] / 150
            azi_action = self.uav_radardata["uav2"][15] / 150
            datain1 = [1, ele_action, azi_action, 0, 0, 0, 0, 3]
            if self.uav_radardata["uav2"][16] < 8000:
                datain1 = [0.6, ele_action, azi_action, 0, 1, 1, 1, 3]
        TCP_client.send_data(datain0, datain1)
        time.sleep(0.5)
        return True

    def combat(self, output1, output2):
        """
        攻击算法
        :param output1: 飞机 1 信息
        :param output2: 飞机 2 信息
        """
        _ = self.get_data(output1, output2)

        if 0 < self.uav_selfdata["uav1"][7] < self.limit_altitude or 0 < self.uav_selfdata["uav2"][
            7] < self.limit_altitude:
            print("紧急状态 1 触发 !!!")
            # 紧急状态 1 -> 飞行高度过低
            _ = self.low_altitude(self.uav_action["uav1"], self.uav_action["uav2"])
        else:
            if self.uav_alertdata["uav1"][3] > 0 or self.uav_alertdata["uav2"][3] > 0:
                print("紧急状态 2 触发 !!!")
                # 紧急状态 2 -> 飞机躲避导弹
                _ = self.avoid_missile(self.uav_action["uav1"], self.uav_action["uav2"])
            else:
                if self.uav_radardata["uav1"][9] > 10000 or self.uav_radardata["uav1"][16] > 10000 or \
                        self.uav_radardata["uav2"][16] > 10000 or self.uav_radardata["uav2"][9] > 10000:
                    print("策略 1 触发 !!! 目标距离", self.uav_radardata["uav1"][9], self.uav_radardata["uav1"][16],
                          self.uav_radardata["uav2"][9], self.uav_radardata["uav2"][16])
                    # 策略 1 -> 追击目标
                    _ = self.attack_target(self.uav_action["uav1"], self.uav_action["uav2"])
                # if 0 < self.uav_radardata["uav1"][9] < 10000 or 0 < self.uav_radardata["uav1"][16] < 10000:
                #     self.uav_action["uav1"][5] = 1
                #     self.uav_action["uav1"][6] = 1
                #     if self.uav_radardata["uav1"][9] < self.uav_radardata["uav1"][16]:
                #         self.uav_action["uav1"][4] = 0
                #     else:
                #         self.uav_action["uav1"][4] = 1
                #     TCP_client.send_data(self.uav_action["uav1"], self.uav_action["uav2"])
                # if self.uav_radardata["uav2"][9] < 10000 or self.uav_radardata["uav2"][16] < 10000:
                #     self.uav_action["uav2"][5] = 1
                #     self.uav_action["uav2"][6] = 1
                #     if self.uav_radardata["uav2"][9] < self.uav_radardata["uav2"][16]:
                #         self.uav_action["uav2"][4] = 0
                #     else:
                #         self.uav_action["uav2"][4] = 1
                #     TCP_client.send_data(self.uav_action["uav1"], self.uav_action["uav2"])
                else:
                    self.uav_action["uav1"][5] = 0
                    self.uav_action["uav1"][6] = 0
                    self.uav_action["uav2"][5] = 0
                    self.uav_action["uav2"][6] = 0
                    TCP_client.send_data(self.uav_action["uav1"], self.uav_action["uav2"])
        return True


if __name__ == '__main__':

    # 初始化TCP通信
    TCP_client = TcpClient(port=42674)
    # 挂起监听线程
    TCP_client.listen_start()
    # data调用
    output0 = TCP_client.simdata0
    output1 = TCP_client.simdata1
    # 攻击模型初始化
    air_combat = AirCombat()
    # 初始化飞机动作，保证友机不在同一高度
    _ = air_combat.init_altitude()
    _ = air_combat.init_action()
    # ###################### 开始单轮仿真 ######################
    while True:
        time.sleep(0.005)  # 为保证程序正常运行不可改动
        # 更新飞机信息
        _ = air_combat.combat(output0, output1)
