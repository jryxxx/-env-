import random
import time

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from basic.TCPclient import TcpClient


class ReplayBuffer:
    """
    定义经验回放池
    """

    def __init__(self, buffer_size):
        self.buffer = []
        self.buffer_size = buffer_size

    def add(self, experience):
        """
        添加经验
        :param experience:
        """
        if len(self.buffer) >= self.buffer_size:
            self.buffer.pop(0)
        self.buffer.append(experience)

    def sample(self, batch_size):
        """
        采样经验
        :param batch_size:
        :return:
        """
        return random.sample(self.buffer, batch_size)


class DQN(nn.Module):
    """
    DQN 模型
    """

    def __init__(self):
        super(DQN, self).__init__()
        self.fc1 = nn.Linear(25, 56)
        self.fc2 = nn.Linear(56, 56)
        self.fc3 = nn.Linear(56, 27)

    def forward(self, x):
        """
        前向传播
        :param x:
        :return:
        """
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return x


class AirCombat:
    """
    空中对抗类
    """

    def __init__(self):
        self.variables = None

    @staticmethod
    def get_state(output):
        """
        获取当前状态
        :param output:
        """
        target1_distance = output.radardata.target1_Distance
        target1_azi_angle = output.radardata.target1_AziAngle
        target1_ele_angle = output.radardata.target1_EleAngle
        target1_survive = float(output.statedata.target1_Survive)
        target2_distance = output.radardata.target2_Distance
        target2_azi_angle = output.radardata.target2_AziAngle
        target2_ele_angle = output.radardata.target2_EleAngle
        target2_survive = float(output.statedata.target2_Survive)
        missile_alert_num = output.alertdata.emergency_missile_num
        missile_alert_azi_angle = output.alertdata.emergency_missile_AziAngle
        missile_alert_ele_angle = output.alertdata.emergency_missile_EleAngle
        # missile_alert_azi_angle = output.alertdata.emergency_missile_AziAngle[0]
        # missile_alert_ele_angle = output.alertdata.emergency_missile_EleAngle[0]
        state = [target1_distance, target1_azi_angle, target1_ele_angle, target1_survive,
                 target2_distance, target2_azi_angle, target2_ele_angle, target2_survive,
                 missile_alert_num] + missile_alert_azi_angle + missile_alert_ele_angle  # 25
        # state = [target1_distance, target1_azi_angle, target1_ele_angle, target1_survive,
        #          target2_distance, target2_azi_angle, target2_ele_angle, target2_survive,
        #          missile_alert_num, missile_alert_azi_angle, missile_alert_ele_angle]  # 11
        return state

    @staticmethod
    def action(index):
        """

        :param index:
        """
        action = [
            # [0.3, 1 / 9, 0, 0, 0, 0, 0, 3],  # 低速，水平
            # [0.3, 1 / 9, 0, 0, 0, 0, 0, 3],
            # [0.3, 1 / 9, 0, 0, 1, 1, 1, 3],
            [0.5, 1 / 9, 0, 0, 0, 0, 0, 3],  # 高速，水平
            [0.5, 1 / 9, 0, 0, 0, 1, 1, 3],
            [0.5, 1 / 9, 0, 0, 1, 1, 1, 3],
            [0.5, 1 / 9 + 0.5, 0, 0, 0, 0, 0, 3],  # 高速，上升
            [0.5, 1 / 9 + 0.5, 0, 0, 0, 1, 1, 3],
            [0.5, 1 / 9 + 0.5, 0, 0, 1, 1, 1, 3],
            [0.5, 1 / 9 - 0.5, 0, 0, 0, 0, 0, 3],  # 高速，下降
            [0.5, 1 / 9 - 0.5, 0, 0, 0, 1, 1, 3],
            [0.5, 1 / 9 - 0.5, 0, 0, 1, 1, 1, 3],
            [0.5, 1 / 9, 0.5, 0, 0, 0, 0, 3],  # 高速，右转
            [0.5, 1 / 9, 0.5, 0, 0, 1, 1, 3],
            [0.5, 1 / 9, 0.5, 0, 1, 1, 1, 3],
            [0.5, 1 / 9, -0.5, 0, 0, 0, 0, 3],  # 高速，左转
            [0.5, 1 / 9, -0.5, 0, 0, 1, 1, 3],
            [0.5, 1 / 9, -0.5, 0, 1, 1, 1, 3],
            [0.5, 1 / 9 + 0.5, 0.5, 0, 0, 0, 0, 3],  # 高速，上升，右转
            [0.5, 1 / 9 + 0.5, 0.5, 0, 0, 1, 1, 3],
            [0.5, 1 / 9 + 0.5, 0.5, 0, 1, 1, 1, 3],
            [0.5, 1 / 9 + 0.5, -0.5, 0, 0, 0, 0, 3],  # 高速，上升，左转
            [0.5, 1 / 9 + 0.5, -0.5, 0, 0, 1, 1, 3],
            [0.5, 1 / 9 + 0.5, -0.5, 0, 1, 1, 1, 3],
            [0.5, 1 / 9 - 0.5, 0.5, 0, 0, 0, 0, 3],  # 高速，下降，右转
            [0.5, 1 / 9 - 0.5, 0.5, 0, 0, 1, 1, 3],
            [0.5, 1 / 9 - 0.5, 0.5, 0, 1, 1, 1, 3],
            [0.5, 1 / 9 - 0.5, -0.5, 0, 0, 0, 0, 3],  # 高速，下降，左转
            [0.5, 1 / 9 - 0.5, -0.5, 0, 0, 1, 1, 3],
            [0.5, 1 / 9 - 0.5, -0.5, 0, 1, 1, 1, 3]]
        return action[index]

    @staticmethod
    def is_hit(x):
        """
        判断是否击中
        :param x:
        """
        if x == 2:
            return 1
        elif x == 3:
            return -1
        else:
            return 0

    def reward(self, output):
        """
        奖励函数
        :param output:
        :return reward:
        """
        reward = 0
        reward += (AirCombat.is_hit(output.selfdata.Missile1State) +
                   AirCombat.is_hit(output.selfdata.Missile2State) +
                   AirCombat.is_hit(output.selfdata.Missile3State) +
                   AirCombat.is_hit(output.selfdata.Missile4State)) * 100  # 攻击
        if output.radardata.target1_Distance > 0:  # 距离，防止初始状态干扰
            reward += (40000 - output.radardata.target1_Distance) / 4000
        if output.radardata.target2_Distance > 0:  # 距离，防止初始状态干扰
            reward += (40000 - output.radardata.target2_Distance) / 4000
        reward -= output.alertdata.emergency_missile_num * 100  # 规避
        reward += (output.selfdata.left_bloods - 1) * 100  # HP 值
        # reward += (output.selfdata.Altitude - 6000) / 10  # 高度
        # reward += (output.selfdata.NumberofFuel - 2240) / 10  # 燃油
        # if output.radardata.friend_Distance > 0:
        #     reward += (output.radardata.friend_Distance - 4000) / 100  # 友机距离
        if output.statedata.friend_Altitude > 0:
            reward += (float(output.statedata.friend_Survive) - 1) * 500  # 友机存活
        if output.selfdata.Longitude > 0 and output.selfdata.Latitude > 0:  # 经纬度，防止初始状态干扰
            reward -= (abs(160.123456 - output.selfdata.Longitude) +
                       abs(24.8976763 - output.selfdata.Latitude)) * 100
        return reward


if __name__ == '__main__':

    # 初始化TCP通信
    TCP_client = TcpClient(port=42674)
    # 挂起监听线程
    TCP_client.listen_start()
    # data调用
    output0 = TCP_client.simdata0
    output1 = TCP_client.simdata1
    # 初始化参数
    gamma = 0.99
    epsilon = 1.0
    epsilon_decay = 0.995
    min_epsilon = 0.01
    buffer_size = 10000
    batch_size = 64
    learning_rate = 0.001
    # 初始状态
    datain0 = [0.5, 1 / 9 + 0.6, 0, 0, 0, 0, 0, 0, 3]  # 保证友军距离
    datain1 = [0.5, 1 / 9, 0, 0, 0, 0, 0, 0, 3]  # 保证友军距离
    TCP_client.send_data(datain0, datain1)
    time.sleep(0.5)
    # 初始化攻击类
    air_combat = AirCombat()
    # 初始化网络和优化器
    policy_net = DQN()
    target_net = DQN()
    target_net.load_state_dict(policy_net.state_dict())
    target_net.eval()
    optimizer = optim.Adam(policy_net.parameters(), lr=learning_rate)
    loss_fn = nn.MSELoss()
    # 初始化经验回放池
    replay_buffer = ReplayBuffer(buffer_size)
    # ###################### 开始单轮仿真 ######################
    while True:
        time.sleep(0.005)  # 为保证程序正常运行不可改动
        if output0.selfdata.Altitude < 4000:  # 限制飞行高度
            datain0 = [1, 0.8, 0, 0, 0, 1, 1, 3]
            TCP_client.send_data(datain0, datain1)
            time.sleep(0.5)
        if output1.selfdata.Altitude < 4000:  # 限制飞行高度
            datain1 = [1, 0.8, 0, 0, 0, 1, 1, 3]
            TCP_client.send_data(datain0, datain1)
            time.sleep(0.5)
        state0, state1 = AirCombat.get_state(output0), AirCombat.get_state(output1)
        if output0.radardata.target1_Distance == 0:
            action0_index = 0
        elif np.random.rand() <= epsilon:
            action0_index = np.random.randint(0, 27)
        else:
            action0_index = policy_net(torch.tensor(state0)).argmax().item()
        if output1.radardata.target1_Distance == 0:
            action1_index = 0
        elif np.random.rand() <= epsilon:
            action1_index = np.random.randint(0, 27)
        else:
            action1_index = policy_net(torch.tensor(state1)).argmax().item()
        # 执行动作
        datain0 = AirCombat.action(action0_index)
        datain1 = AirCombat.action(action1_index)
        TCP_client.send_data(datain0, datain1)
        time.sleep(0.1)
        # 获取奖励和下一个状态
        reward0 = air_combat.reward(output0)
        reward1 = air_combat.reward(output1)
        next_state0 = AirCombat.get_state(output0)
        next_state1 = AirCombat.get_state(output1)
        # 存储经验
        replay_buffer.add((state0, action0_index, reward0, next_state0))
        replay_buffer.add((state1, action1_index, reward1, next_state1))
        # 从经验池中采样训练
        if len(replay_buffer.buffer) >= batch_size:
            batch = replay_buffer.sample(batch_size)
            states, actions, rewards, next_states = zip(*batch)
            states = torch.tensor(states)
            actions = torch.tensor(actions).unsqueeze(1)
            rewards = torch.tensor(rewards).unsqueeze(1)
            next_states = torch.tensor(next_states)
            # 当前 Q 值
            q_values = policy_net(states).gather(1, actions)
            # 目标 Q 值
            with torch.no_grad():
                next_q_values = target_net(next_states).max(1)[0].unsqueeze(1)
                target_q_values = rewards + gamma * next_q_values
            # 更新网络
            loss = loss_fn(q_values, target_q_values)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        # 更新目标网络
        if random.random() < 0.01:
            target_net.load_state_dict(policy_net.state_dict())
        # 减小探索概率
        if epsilon > min_epsilon:
            epsilon *= epsilon_decay
        # 打印调试信息
        print(f'Aircraft 0: Action={datain0}, Reward={reward0}')
        print(f'Aircraft 1: Action={datain1}, Reward={reward1}')
        # 保存模型
        # save_path = "weights/best.pth"
        # torch.save({
        #     'policy_net': policy_net.state_dict(),
        #     'target_net': target_net.state_dict(),
        #     'epsilon': epsilon,
        # }, save_path)
        # 加载模型
        # model_path = "weights/best.pth"
        # checkpoint = torch.load(model_path)
        # policy_net.load_state_dict(checkpoint['policy_net'])
        # target_net.load_state_dict(checkpoint['target_net'])
