from basic.simulation_env import CombatEnv
from SimArg import InitialData, FighterDataIn
from basic.TCPserver import TcpServer
import time

if __name__ == '__main__':
    # ##################### 初始化设定 ########################
    # 初始化环境与输入量
    data_initial = InitialData()
    datain = [FighterDataIn() for m in range(4)]
    env = CombatEnv(data_initial)

    # 初始化TCP通信
    # port表示端口号（均为本地连接）
    TCP_server = TcpServer(port=42674, blue_start=True, red_start=True)

    ####################### 开始多轮仿真 #######################
    for i_episode in range(data_initial.epoch_max):
        # 重置仿真
        env.reset(data_initial)

        # ###################### 开始单轮仿真 ######################
        for t in range(data_initial.len_max):
            # 打印数据
            print('\n仿真步长：', t, '仿真时间： ', t * 0.05)
            time.sleep(0.01)
            # —————————————————————————————————— 编辑输入控制数据 ——————————————————————————————————————
            # 在回合开始前，先读取客户端输出的飞机控制数据
            TCP_server.read_data(datain)
            # 单个回合更新
            terminal = env.update(datain)

            # 向客户端发送最新的环境数据
            TCP_server.send_data(env, t)
            # tcp可视化更新
            env.tcp_update(t)


            # 仿真结束
            if terminal >= 0:
                # 得分记录
                score = env.score(terminal)
                print("Episode: \t{} ,episode len is: \t{}".format(i_episode, t))
                for key in score:
                    print(f"{key}: {score[key]}")
                print(terminal)
                break
